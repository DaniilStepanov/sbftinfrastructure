/**
 Contains the main {@link org.jsoup.Jsoup} class, which provides convenient static access to the jsoup functionality.
 */
@NonnullByDefault
package org.jsoup;

import org.jsoup.internal.NonnullByDefault;
