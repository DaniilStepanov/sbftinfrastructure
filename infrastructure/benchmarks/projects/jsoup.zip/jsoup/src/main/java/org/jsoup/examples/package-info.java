/**
 Contains example programs and use of jsoup. See the <a href="https://jsoup.org/cookbook/">jsoup cookbook</a>.
 */
package org.jsoup.examples;