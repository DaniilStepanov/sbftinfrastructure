# Notices for Spatial4j

This content is produced and maintained by the Eclipse Spatial4j project.

 * Project home: https://projects.eclipse.org/projects/locationtech.spatial4j

## Trademarks

LocationTech Spatial4j, and Spatial4j are trademarks of the Eclipse Foundation.

## Declared Project Licenses

This program and the accompanying materials are made available under the terms
of the Apache License, Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0.

SPDX-License-Identifier: Apache-2.0

## Source Code

The project maintains the following source code repositories:

 * https://github.com/locationtech/spatial4j

## Third-party Content

(none)

## Cryptography

(none)